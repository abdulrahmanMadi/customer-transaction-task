export const environment = {
  DB_URL: 'https://my-json-server.typicode.com/ahmedd0/customer-transaction',
};
