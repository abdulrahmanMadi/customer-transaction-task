export interface Transactions {
  id: number;
  customer_id: number;
  amount: number;
  date: string;
}
